﻿PRINT '========================================';
PRINT 'BAŞLANIYOR: Belge Onay Sistemi Setup';
PRINT '========================================';
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'Kullanicilar')
BEGIN
    CREATE TABLE [dbo].[Kullanicilar]
    (
        [Id] INT IDENTITY(1,1) PRIMARY KEY,
        [KullaniciAdi] NVARCHAR(100) UNIQUE NOT NULL,
        [AdSoyad] NVARCHAR(150) NOT NULL,
        [Sifre] NVARCHAR(255) NULL,
        [Rol] NVARCHAR(50) NOT NULL,
        [AktifMi] BIT DEFAULT 1,
        [OlusturulmaTarihi] DATETIME2 DEFAULT SYSDATETIME()
    );
    
    PRINT '✓ Kullanicilar tablosu oluşturuldu.';
END
ELSE
BEGIN
    PRINT '✓ Kullanicilar tablosu zaten mevcut.';
END;
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'BelgeGonderim')
BEGIN
    CREATE TABLE [dbo].[BelgeGonderim]
    (
        [Id] INT IDENTITY(1,1) PRIMARY KEY,
        [DokumanTuru] NVARCHAR(100) NOT NULL,
        [Direktorluk] NVARCHAR(100) NOT NULL,
        [Konu] NVARCHAR(500) NOT NULL,
        [Aciklama] NVARCHAR(MAX),
        
        [DosyaYolu] NVARCHAR(MAX) NOT NULL,
        [ImzaliDosya1Yolu] NVARCHAR(MAX),
        [ImzaliDosya2Yolu] NVARCHAR(MAX),

        [VersiyonNo] INT DEFAULT 1,
        [OncekiId] INT NULL,

        [OnayDurumu] NVARCHAR(100),
        [RevizeAciklama] NVARCHAR(MAX),

        [GonderenKullaniciAdi] NVARCHAR(100),
        [GonderenAdSoyad] NVARCHAR(150),

        [Onayci1Id] INT,
        [Onayci2Id] INT,

        [Onaylayan] NVARCHAR(150),
        [OnayTarihi] DATETIME2,

        [KayitTarihi] DATETIME2 DEFAULT SYSDATETIME(),

        CONSTRAINT FK_BelgeGonderim_OncekiId FOREIGN KEY ([OncekiId])
            REFERENCES [dbo].[BelgeGonderim]([Id]) ON DELETE SET NULL,
        CONSTRAINT FK_BelgeGonderim_Onayci1 FOREIGN KEY ([Onayci1Id])
            REFERENCES [dbo].[Kullanicilar]([Id]) ON DELETE SET NULL,
        CONSTRAINT FK_BelgeGonderim_Onayci2 FOREIGN KEY ([Onayci2Id])
            REFERENCES [dbo].[Kullanicilar]([Id]) ON DELETE SET NULL
    );
    
    CREATE INDEX IX_BelgeGonderim_OnayDurumu ON [dbo].[BelgeGonderim]([OnayDurumu]);
    CREATE INDEX IX_BelgeGonderim_Onayci1 ON [dbo].[BelgeGonderim]([Onayci1Id]);
    CREATE INDEX IX_BelgeGonderim_Onayci2 ON [dbo].[BelgeGonderim]([Onayci2Id]);
    CREATE INDEX IX_BelgeGonderim_KayitTarihi ON [dbo].[BelgeGonderim]([KayitTarihi]);
    
    PRINT '✓ BelgeGonderim tablosu oluşturuldu.';
END
ELSE
BEGIN
    PRINT '✓ BelgeGonderim tablosu zaten mevcut.';
END;
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'BelgeLog')
BEGIN
    CREATE TABLE [dbo].[BelgeLog]
    (
        [Id] INT IDENTITY(1,1) PRIMARY KEY,
        [BelgeId] INT NOT NULL,
        [IslemTipi] NVARCHAR(50) NOT NULL,
        [IslemYapanId] INT NOT NULL,
        [IslemYapanAdi] NVARCHAR(150),
        [Aciklama] NVARCHAR(MAX),
        [IslemTarihi] DATETIME2 DEFAULT SYSDATETIME(),
        
        CONSTRAINT FK_BelgeLog_BelgeGonderim FOREIGN KEY ([BelgeId])
            REFERENCES [dbo].[BelgeGonderim]([Id]) ON DELETE CASCADE,
        CONSTRAINT FK_BelgeLog_Kullanicilar FOREIGN KEY ([IslemYapanId])
            REFERENCES [dbo].[Kullanicilar]([Id]) ON DELETE NO ACTION
    );

    CREATE INDEX IX_BelgeLog_BelgeId ON [dbo].[BelgeLog]([BelgeId]);
    CREATE INDEX IX_BelgeLog_IslemTarihi ON [dbo].[BelgeLog]([IslemTarihi]);
    CREATE INDEX IX_BelgeLog_IslemYapanId ON [dbo].[BelgeLog]([IslemYapanId]);

    PRINT '✓ BelgeLog tablosu oluşturuldu.';
END
ELSE
BEGIN
    PRINT '✓ BelgeLog tablosu zaten mevcut.';
END;
GO

IF COL_LENGTH('BelgeGonderim', 'VersiyonNo') IS NULL
BEGIN
    ALTER TABLE [dbo].[BelgeGonderim] ADD [VersiyonNo] INT DEFAULT 1;
    PRINT '✓ VersiyonNo kolonu eklendi.';
END;

IF COL_LENGTH('BelgeGonderim', 'KayitTarihi') IS NULL
BEGIN
    ALTER TABLE [dbo].[BelgeGonderim] ADD [KayitTarihi] DATETIME2 DEFAULT SYSDATETIME();
    PRINT '✓ KayitTarihi kolonu eklendi.';
END;

IF COL_LENGTH('BelgeGonderim', 'OncekiId') IS NULL
BEGIN
    ALTER TABLE [dbo].[BelgeGonderim] ADD [OncekiId] INT NULL;
    ALTER TABLE [dbo].[BelgeGonderim] ADD CONSTRAINT FK_BelgeGonderim_OncekiId FOREIGN KEY ([OncekiId])
        REFERENCES [dbo].[BelgeGonderim]([Id]) ON DELETE SET NULL;
    PRINT '✓ OncekiId kolonu eklendi.';
END;

IF COL_LENGTH('BelgeGonderim', 'ImzaliDosya1Yolu') IS NULL
BEGIN
    ALTER TABLE [dbo].[BelgeGonderim] ADD [ImzaliDosya1Yolu] NVARCHAR(MAX) NULL;
    PRINT '✓ ImzaliDosya1Yolu kolonu eklendi.';
END;

IF COL_LENGTH('BelgeGonderim', 'ImzaliDosya2Yolu') IS NULL
BEGIN
    ALTER TABLE [dbo].[BelgeGonderim] ADD [ImzaliDosya2Yolu] NVARCHAR(MAX) NULL;
    PRINT '✓ ImzaliDosya2Yolu kolonu eklendi.';
END;

IF COL_LENGTH('BelgeGonderim', 'GonderenKullaniciAdi') IS NULL
BEGIN
    ALTER TABLE [dbo].[BelgeGonderim] ADD [GonderenKullaniciAdi] NVARCHAR(100) NULL;
    PRINT '✓ GonderenKullaniciAdi kolonu eklendi.';
END;

IF COL_LENGTH('BelgeGonderim', 'Onaylayan') IS NULL
BEGIN
    ALTER TABLE [dbo].[BelgeGonderim] ADD [Onaylayan] NVARCHAR(150) NULL;
    PRINT '✓ Onaylayan kolonu eklendi.';
END;

IF COL_LENGTH('BelgeGonderim', 'OnayTarihi') IS NULL
BEGIN
    ALTER TABLE [dbo].[BelgeGonderim] ADD [OnayTarihi] DATETIME2 NULL;
    PRINT '✓ OnayTarihi kolonu eklendi.';
END;

IF COL_LENGTH('BelgeGonderim', 'RevizeAciklama') IS NULL
BEGIN
    ALTER TABLE [dbo].[BelgeGonderim] ADD [RevizeAciklama] NVARCHAR(MAX) NULL;
    PRINT '✓ RevizeAciklama kolonu eklendi.';
END;

GO

PRINT '';
PRINT 'TEST VERİSİ EKLENİYOR...';
PRINT '';
IF NOT EXISTS (SELECT 1 FROM Kullanicilar WHERE KullaniciAdi = 'ztuncay')
BEGIN
    INSERT INTO Kullanicilar (KullaniciAdi, AdSoyad, Rol)
    VALUES ('ztuncay', 'Zeynep Tuncay', 'Kalite');
    PRINT '✓ Zeynep Tuncay (Kalite) eklendi.';
END
ELSE
BEGIN
    PRINT '⚠ Zeynep Tuncay zaten mevcut.';
END;

IF NOT EXISTS (SELECT 1 FROM Kullanicilar WHERE KullaniciAdi = 'zeynep_director')
BEGIN
    INSERT INTO Kullanicilar (KullaniciAdi, AdSoyad, Rol)
    VALUES ('zeynep_director', 'Zeynep Yönetici', 'Onayci');
    PRINT '✓ Zeynep Yönetici (Onaycı) eklendi.';
END
ELSE
BEGIN
    PRINT '⚠ Zeynep Yönetici zaten mevcut.';
END;

IF NOT EXISTS (SELECT 1 FROM Kullanicilar WHERE KullaniciAdi = 'zeynepp_director')
BEGIN
    INSERT INTO Kullanicilar (KullaniciAdi, AdSoyad, Rol)
    VALUES ('zeynepp_director', 'Zeynepp Direktör', 'Onayci');
    PRINT '✓ Zeynepp Direktör (Onaycı) eklendi.';
END
ELSE
BEGIN
    PRINT '⚠ Zeynep Direktör zaten mevcut.';
END;

IF NOT EXISTS (SELECT 1 FROM Kullanicilar WHERE KullaniciAdi = 'view_only')
BEGIN
    INSERT INTO Kullanicilar (KullaniciAdi, AdSoyad, Rol)
    VALUES ('view_only', 'Okuma Kullanıcısı', 'Goruntuleme');
    PRINT '✓ Okuma Kullanıcısı (Görüntüleme) eklendi.';
END
ELSE
BEGIN
    PRINT '⚠ Okuma Kullanıcısı zaten mevcut.';
END;

GO

PRINT '';
PRINT '========================================';
PRINT 'SETUP TAMAMLANDI!';
PRINT '========================================';

SELECT 
    'Toplam Tablo Sayısı: ' + CAST(COUNT(*) AS VARCHAR(10)) as [Özet]
FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_TYPE = 'BASE TABLE' 
  AND TABLE_SCHEMA = 'dbo';

SELECT 
    'Toplam Kullanıcı Sayısı: ' + CAST(COUNT(*) AS VARCHAR(10)) as [Özet]
FROM Kullanicilar;

SELECT 
    'Toplam Belge Sayısı: ' + CAST(COUNT(*) AS VARCHAR(10)) as [Özet]
FROM BelgeGonderim;

PRINT '';
PRINT 'TABLOLAR:';
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES 
WHERE TABLE_SCHEMA = 'dbo' AND TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;

PRINT '';
PRINT 'KULLANICILAR:';
SELECT 
    '[' + CAST(Id AS VARCHAR(3)) + '] ' + KullaniciAdi + ' - ' + AdSoyad + ' (' + Rol + ')' as [Kullanıcı Bilgisi]
FROM Kullanicilar
ORDER BY Rol, AdSoyad;

PRINT '';
PRINT '========================================';
PRINT 'UYGULAMAYI ŞU KREDENSİYELLER İLE TEST ET:';
PRINT '========================================';
PRINT 'Kullanıcı Adı: ztuncay';
PRINT 'Şifre: (boş bırak)';
PRINT '========================================';
GO
PRINT '';
PRINT '=== SETUP COMPLETE ===';
PRINT 'BelgeLog tablosu oluşturuldu ve/veya BelgeGonderim eksik kolonları eklendi.';
PRINT 'Sistem artık log kayıt yapabilir duruma gelmiştir.';
