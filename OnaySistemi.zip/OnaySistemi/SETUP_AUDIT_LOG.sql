PRINT 'AUDIT LOG TABLOSU OLUSTURULUYOR...';
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'AuditLog')
BEGIN
    CREATE TABLE [dbo].[AuditLog]
    (
        [Id] INT IDENTITY(1,1) PRIMARY KEY,
        [IslemTarihi] DATETIME2 DEFAULT SYSDATETIME(),
        [KullaniciAdi] NVARCHAR(100),
        [IslemTipi] NVARCHAR(50),
        [Tablo] NVARCHAR(50),
        [KaydId] INT,
        [Aciklama] NVARCHAR(MAX),
        INDEX IX_AuditLog_IslemTarihi (IslemTarihi DESC),
        INDEX IX_AuditLog_KullaniciAdi (KullaniciAdi),
        INDEX IX_AuditLog_IslemTipi (IslemTipi)
    );
    
    PRINT 'Tablo olusturuldu - Kurulum tamamlandi!';
END
ELSE
BEGIN
    PRINT 'Tablo zaten mevcut.';
END;
GO
