PRINT 'Kullanicilar tablosuna Email alani ekleniyor...';
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'Kullanicilar' AND COLUMN_NAME = 'Email')
BEGIN
    ALTER TABLE Kullanicilar
    ADD Email NVARCHAR(255) NULL;
    
    PRINT 'Email alani eklendi.';
END
ELSE
BEGIN
    PRINT 'Email alani zaten mevcut.';
END;
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'Kullanicilar' AND COLUMN_NAME = 'MailBildirimAktif')
BEGIN
    ALTER TABLE Kullanicilar
    ADD MailBildirimAktif BIT DEFAULT 1;
    
    PRINT 'MailBildirimAktif alani eklendi.';
END
ELSE
BEGIN
    PRINT 'MailBildirimAktif alani zaten mevcut.';
END;
GO

PRINT 'Islem tamamlandi!';
GO
