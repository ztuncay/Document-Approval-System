using System;
using System.Configuration;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace OnaySistemi
{
    public partial class FrmSifreDe�i�tir : Form
    {
        private readonly string _baglantiMetni;

        public FrmSifreDe�i�tir()
        {
            InitializeComponent();
            _baglantiMetni = ConfigurationManager.ConnectionStrings["OnaySystem"].ConnectionString;
        }

        private void FrmSifreDe�i�tir_Load(object sender, EventArgs e)
        {
            lblKullanici.Text = $"Kullan�c�: {OturumBilgisi.AdSoyad} ({OturumBilgisi.KullaniciAdi})";
            lblGereksinimler.Text = "Gereken: Minimum 6 karakter, en az 1 rakam, en az 1 b�y�k harf";
            
            txtEskiSifre.Focus();
        }

        private void btnDe�i�tir_Click(object sender, EventArgs e)
        {
            lblMesaj.Text = "";
            lblMesaj.ForeColor = System.Drawing.Color.Red;

            string eskiSifre = txtEskiSifre.Text;
            string yeniSifre = txtYeniSifre.Text;
            string yeniSifreDo�rula = txtYeniSifreDo�rula.Text;

            if (string.IsNullOrWhiteSpace(eskiSifre))
            {
                lblMesaj.Text = "Eski �ifre bo� b�rak�lamaz.";
                return;
            }

            if (string.IsNullOrWhiteSpace(yeniSifre))
            {
                lblMesaj.Text = "Yeni �ifre bo� b�rak�lamaz.";
                return;
            }

            if (string.IsNullOrWhiteSpace(yeniSifreDo�rula))
            {
                lblMesaj.Text = "Yeni �ifre (do�rulama) bo� b�rak�lamaz.";
                return;
            }

            if (yeniSifre != yeniSifreDo�rula)
            {
                lblMesaj.Text = "Yeni �ifreler e�le�miyor.";
                return;
            }

            if (eskiSifre == yeniSifre)
            {
                lblMesaj.Text = "Yeni �ifre eski �ifre ile ayn� olamaz.";
                return;
            }

            var (gecerli, mesaj) = SifreServisi.SifreGe�erlili�iKontrol(yeniSifre);
            if (!gecerli)
            {
                lblMesaj.Text = mesaj;
                return;
            }

            try
            {
                string dbHashliSifre = "";

                using (SqlConnection baglanti = new SqlConnection(_baglantiMetni))
                using (SqlCommand komut = new SqlCommand(
                    "SELECT Sifre FROM Kullanicilar WHERE Id = @Id", baglanti))
                {
                    komut.Parameters.AddWithValue("@Id", OturumBilgisi.KullaniciId);
                    baglanti.Open();

                    object result = komut.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        dbHashliSifre = Convert.ToString(result);
                    }
                }

                if (!SifreServisi.SifreDo�rula(eskiSifre, dbHashliSifre))
                {
                    lblMesaj.Text = "Eski �ifre hatal�.";
                    return;
                }

                string yeniHashliSifre = SifreServisi.SifreHashle(yeniSifre);

                using (SqlConnection baglanti = new SqlConnection(_baglantiMetni))
                using (SqlCommand komut = new SqlCommand(
                    "UPDATE Kullanicilar SET Sifre = @Sifre WHERE Id = @Id", baglanti))
                {
                    komut.Parameters.AddWithValue("@Sifre", yeniHashliSifre);
                    komut.Parameters.AddWithValue("@Id", OturumBilgisi.KullaniciId);

                    baglanti.Open();
                    komut.ExecuteNonQuery();
                }

                AuditLogHelper.SifreGuncellendi(OturumBilgisi.KullaniciId, OturumBilgisi.KullaniciAdi);

                lblMesaj.Text = "�ifre ba�ar�yla de�i�tirildi!";
                lblMesaj.ForeColor = System.Drawing.Color.Green;

                btnKapat.Enabled = true;
                btnDe�i�tir.Enabled = false;

                System.Threading.Thread.Sleep(1500);
                this.Close();
            }
            catch (Exception ex)
            {
                lblMesaj.Text = "�ifre de�i�tirirken hata olu�tu: " + ex.Message;
                lblMesaj.ForeColor = System.Drawing.Color.Red;
            }
        }

        private void btnKapat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void chkSifreGoster_CheckedChanged(object sender, EventArgs e)
        {
            char passwordChar = chkSifreGoster.Checked ? '\0' : '?';
            txtEskiSifre.PasswordChar = passwordChar;
            txtYeniSifre.PasswordChar = passwordChar;
            txtYeniSifreDo�rula.PasswordChar = passwordChar;
        }
    }
}
