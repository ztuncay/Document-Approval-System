﻿# MAİL BİLDİRİM SİSTEMİ KURULUM KILAVUZU

## 📧 Genel Bakış

Onay Sistemi artık otomatik mail bildirimleri göndermektedir:

### Onaycılara Giden Bildirimler
- ✅ **Yeni belge gönderildiğinde:** "Uygulamada onayınızı bekleyen belge bulunmaktadır"
- ✅ **1. onay verildikten sonra:** 2. Onaycıya bildirim gider

### Gönderene Giden Bildirimler
- ✅ **Belge onaylandığında:** "Gönderdiğiniz *** belgesi onaylandı"
- ✅ **Belge reddedildiğinde:** "Gönderdiğiniz *** belgesi reddedildi"
- ✅ **Revize talep edildiğinde:** "Gönderdiğiniz *** belgesi için revize talep edildi"

---

## 🔧 KURULUM ADIMLARI

### 1. Veritabanı Güncellemesi

SQL Server'da `ADD_EMAIL_TO_USERS.sql` scriptini çalıştırın:

```sql
-- Kullanicilar tablosuna Email ve MailBildirimAktif alanlarını ekler
```

Bu script:
- `Email` kolonu ekler (kullanıcı mail adresleri için)
- `MailBildirimAktif` kolonu ekler (kullanıcı bazında açma/kapama)

### 2. SMTP Ayarları (App.config)

`App.config` dosyasında aşağıdaki ayarları yapılandırın:

```xml
<!-- Mail Bildirimleri -->
<add key="MailBildirimAktif" value="true" />
<add key="SmtpServer" value="smtp.gmail.com" />
<add key="SmtpPort" value="587" />
<add key="SmtpKullanici" value="yourmail@gmail.com" />
<add key="SmtpSifre" value="your-app-password" />
<add key="GondericiMail" value="yourmail@gmail.com" />
<add key="GondericiAd" value="Onay Sistemi" />
```

#### Gmail için Önemli Not:

Gmail kullanıyorsanız **Uygulama Şifresi** oluşturmanız gerekir:

1. Google Hesabınıza gidin
2. Güvenlik > 2 Adımlı Doğrulama'yı aktif edin
3. Güvenlik > Uygulama Şifreleri bölümünden yeni şifre oluşturun
4. Oluşturulan şifreyi `SmtpSifre` anahtarına yazın

#### Kurumsal Mail Sunucusu İçin:

```xml
<!-- Örnek: Microsoft Exchange / Office 365 -->
<add key="SmtpServer" value="smtp.office365.com" />
<add key="SmtpPort" value="587" />
<add key="SmtpKullanici" value="ztuncay@oypa.com.tr" />
<add key="SmtpSifre" value="sifreniz" />
```

### 3. Kullanıcı Email Adreslerini Ekleyin

Admin Panel > Kullanıcı Düzenle ekranından kullanıcıların email adreslerini girin:

- Kullanıcı listesinden bir kullanıcı seçin
- Email alanına geçerli bir email adresi girin
- Mail bildirimlerini açmak için `MailBildirimAktif` kutucuğunu işaretleyin
- Kaydet butonuna tıklayın

---

## 📬 MAİL BİLDİRİMLERİ

### 1. Yeni Belge Onay Bildirimi

**Kime:** Onaycı(lar)  
**Ne Zaman:** 
- Kalite birimi yeni belge gönderdiğinde → 1. Onaycıya
- 1. Onaycı onayladığında → 2. Onaycıya (eğer varsa)

**İçerik:**
```
Uygulamada onayınızı bekleyen belge bulunmaktadır.

Belge No: 123
Belge Konusu: Prosedür XYZ
Gönderen: Ahmet Yılmaz
Tarih: 15.01.2024 14:30

Lütfen Onay Sistemi uygulamasını kullanarak 
belgeyi inceleyin ve onayınızı veriniz.
```

### 2. Belge Onaylandı Bildirimi

**Kime:** Belgeyi Gönderen  
**Ne Zaman:** 
- 1. Onaycı onayladığında (tek onaycılıysa)
- 2. Onaycı onayladığında (çift onaycılıysa)

**İçerik:**
```
Gönderdiğiniz 'Prosedür XYZ' belgesi onaylandı

Belge No: 123
Belge Konusu: Prosedür XYZ
Onaylayan: Mehmet Demir
Tarih: 15.01.2024 15:00

✓ Belgeniz onaylanmıştır.
```

### 3. Belge Reddedildi Bildirimi

**Kime:** Belgeyi Gönderen  
**Ne Zaman:** Onaycı belgeyi reddettiğinde  

**İçerik:**
```
Gönderdiğiniz 'Prosedür XYZ' belgesi reddedildi

Belge No: 123
Belge Konusu: Prosedür XYZ
Reddeden: Mehmet Demir
Red Nedeni: Belirtilmedi
Tarih: 15.01.2024 15:00

✗ Belgeniz reddedilmiştir. 
Lütfen belgenizi gözden geçirip tekrar gönderin.
```

### 4. Revize Talep Bildirimi

**Kime:** Belgeyi Gönderen  
**Ne Zaman:** Onaycı revize talep ettiğinde  

**İçerik:**
```
Gönderdiğiniz 'Prosedür XYZ' belgesi için revize talep edildi

Belge No: 123
Belge Konusu: Prosedür XYZ
Revize Talep Eden: Mehmet Demir
Revize Gerekçesi: Madde 5.3 güncellenmelidir
Tarih: 15.01.2024 15:00

⚠ Lütfen belgenizi revize edip tekrar gönderiniz.
```

---

## 🔄 Mail Akış Senaryoları

### Senaryo 1: Tek Onaycılı Belge

1. **Kalite → Belge Gönder**
   - Mail gider: 1. Onaycıya
   - Konu: "Uygulamada onayınızı bekleyen belge bulunmaktadır"

2. **Onaycı → Onayla**
   - Mail gider: Gönderene
   - Konu: "Gönderdiğiniz *** belgesi onaylandı"

### Senaryo 2: Çift Onaycılı Belge

1. **Kalite → Belge Gönder**
   - Mail gider: 1. Onaycıya
   - Konu: "Uygulamada onayınızı bekleyen belge bulunmaktadır"

2. **1. Onaycı → Onayla**
   - Mail gider: 2. Onaycıya
   - Konu: "Uygulamada onayınızı bekleyen belge bulunmaktadır"
   - Mail GİTMEZ: Gönderene (henüz tam onay değil)

3. **2. Onaycı → Onayla**
   - Mail gider: Gönderene
   - Konu: "Gönderdiğiniz *** belgesi onaylandı"

### Senaryo 3: Belge Reddedildi

1. **Kalite → Belge Gönder**
   - Mail gider: 1. Onaycıya

2. **Onaycı → Reddet**
   - Mail gider: Gönderene
   - Konu: "Gönderdiğiniz *** belgesi reddedildi"

### Senaryo 4: Revize Talep

1. **Kalite → Belge Gönder**
   - Mail gider: 1. Onaycıya

2. **Onaycı → Revize Talep**
   - Mail gider: Gönderene
   - Konu: "Gönderdiğiniz *** belgesi için revize talep edildi"
   - Revize gerekçesi de mailde belirtilir

---

## ⚙️ YAPILANDIRMA

### Sistem Genelinde Mail Bildirimlerini Kapatma

`App.config` dosyasında:

```xml
<add key="MailBildirimAktif" value="false" />
```

### Kullanıcı Bazında Mail Bildirimlerini Kapatma

Admin Panel > Kullanıcı Düzenle:
- `MailBildirimAktif` kutucuğunun işaretini kaldırın

---

## 🐛 SORUN GİDERME

### Mail Gönderilmiyor

1. **SMTP Ayarlarını Kontrol Edin:**
   - Server ve port bilgileri doğru mu?
   - Kullanıcı adı ve şifre doğru mu?
   
2. **Güvenlik Duvarı:**
   - Port 587 (TLS) veya 465 (SSL) açık mı?

3. **Debug Loglarını İnceleyin:**
   - Visual Studio Output penceresinde hata mesajlarını kontrol edin
   - Mail gönderme hataları Debug.WriteLine ile loglanır

4. **Kullanıcı Email Ayarları:**
   - Kullanıcının email adresi girildi mi?
   - MailBildirimAktif = true mi?

### Gmail "Güvenli Olmayan Uygulama" Hatası

- 2 Adımlı Doğrulama aktif olmalı
- Uygulama Şifresi kullanılmalı (normal şifre değil)

### Mail Gidiyor Ama Spam'e Düşüyor

- Kurumsal mail sunucusu kullanmanız önerilir
- SPF ve DKIM kayıtlarını kontrol edin

### Sadece Bazı Kullanıcılara Mail Gidiyor

- Kullanıcı email adresleri kontrol edin
- MailBildirimAktif değerini kontrol edin
- Debug loglarında hangi maillerin gönderildiğini kontrol edin

---

## 📊 KULLANICI YÖNETİMİ

### Toplu Email Güncelleme (SQL)

Tüm kullanıcılara varsayılan domain eklemek için:

```sql
UPDATE Kullanicilar 
SET Email = KullaniciAdi + '@oypa.com',
    MailBildirimAktif = 1
WHERE Email IS NULL;
```

### Mail Bildirimi Alan Kullanıcıları Listeleme

```sql
SELECT KullaniciAdi, AdSoyad, Email, MailBildirimAktif
FROM Kullanicilar
WHERE MailBildirimAktif = 1 
  AND Email IS NOT NULL
ORDER BY AdSoyad;
```

### Belirli Rol için Mail Bildirimlerini Toplu Açma

```sql
UPDATE Kullanicilar
SET MailBildirimAktif = 1
WHERE Rol = 'Onayci' AND Email IS NOT NULL;
```

---

## 🔒 GÜVENLİK

- SMTP şifreleri `App.config` dosyasında şifreli tutulmalıdır
- Üretim ortamında `App.config` şifreleme önerilir:

```powershell
aspnet_regiis -pef "appSettings" "C:\YourAppPath"
```

---

## ✅ TEST

Mail sistemini test etmek için:

1. Kendinize bir test belgesi gönderin
2. Debug modunda çalıştırın
3. Output penceresinde mail loglarını kontrol edin:
   ```
   Mail gonderildi: user@example.com - Uygulamada onayınızı bekleyen belge bulunmaktadır
   ```
4. Email kutunuzu kontrol edin

---

## 📝 ÖZELLEŞTİRME

Mail şablonlarını özelleştirmek için `MailHelper.cs` dosyasını düzenleyin:

### Mevcut Mail Fonksiyonları

- `BelgeOnayBildirimi()` - Onaycılara "Onayınızı bekleyen belge" maili
- `BelgeOnaylandi()` - Gönderene "Belgeniz onaylandı" maili
- `BelgeReddedildi()` - Gönderene "Belgeniz reddedildi" maili
- `BelgeRevizeTalep()` - Gönderene "Revize talep edildi" maili
- `BelgeDurumDegisikligi()` - Genel durum değişikliği maili

### HTML Tasarım

Tüm mailler HTML formatındadır. Örnek tasarım:

```html
<div style='background-color: #fff3cd; padding: 15px; border-left: 4px solid #ffc107;'>
    <p><strong>Belge No:</strong> 123</p>
    <p><strong>Belge Konusu:</strong> Prosedür XYZ</p>
</div>
```

Renk kodları:
- 🟡 Onay Bekliyor: `#ffc107` (Sarı)
- 🟢 Onaylandı: `#4caf50` (Yeşil)
- 🔴 Reddedildi: `#f44336` (Kırmızı)
- 🟠 Revize: `#ff9800` (Turuncu)

---

## 📈 İSTATİSTİKLER

Gönderilen mailleri takip etmek için:

```sql
-- Mail gönderimi tetikleyen işlemleri görüntüle
SELECT 
    IslemTipi,
    COUNT(*) as Toplam,
    MAX(IslemTarihi) as SonIslem
FROM AuditLog
WHERE IslemTipi LIKE '%Belge%'
GROUP BY IslemTipi
ORDER BY Toplam DESC;
```

---

## 💡 İPUÇLARI

1. **Test Ortamı:** İlk testlerde sadece kendi email adresinizi kullanın
2. **Spam Kontrolü:** İlk maili aldıktan sonra "Spam Değil" olarak işaretleyin
3. **Performans:** Mail gönderimi asenkron çalışır, uygulamayı yavaşlatmaz
4. **Hata Yönetimi:** Mail gönderilemese bile uygulama çalışmaya devam eder
5. **Log Takibi:** Tüm mail işlemleri Debug loglarına yazılır

---

**Not:** Mail gönderimi hataları uygulamayı durdurmaz (silent fail). Tüm hatalar Debug loglarına yazılır.

---

## 📞 DESTEK

Sorun yaşıyorsanız:
1. Output penceresindeki logları kontrol edin
2. Email ayarlarını doble check edin
3. Test maili gönderin
4. Debug modda adım adım takip edin
