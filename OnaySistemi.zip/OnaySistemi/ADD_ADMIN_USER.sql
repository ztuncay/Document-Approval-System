IF NOT EXISTS (SELECT 1 FROM Kullanicilar WHERE KullaniciAdi = 'admin')
BEGIN
    INSERT INTO Kullanicilar (KullaniciAdi, AdSoyad, Sifre, Rol, AktifMi, OlusturulmaTarihi)
    VALUES ('admin', 'Sistem Y�neticisi', '', 'Yonetici', 1, SYSDATETIME());
    
    PRINT 'Admin hesab� ba�ar�yla olu�turuldu.';
    PRINT '========================================';
    PRINT 'Kullan�c� Ad�: admin';
    PRINT '�ifre: (bo� - herhangi bir �ifre yazabilirsin)';
    PRINT '========================================';
    PRINT 'KURULUM SONRASI:';
    PRINT '1. admin ile giri� yap';
    PRINT '2. "�ifre De�i�tir" butonuna t�kla';
    PRINT '3. Yeni �ifre: 1234';
    PRINT '4. Kaydet';
    PRINT '========================================';
END
ELSE
BEGIN
    PRINT 'Admin hesab� zaten mevcut.';
    PRINT '�ifre de�i�tirmek i�in "�ifre De�i�tir" �zelli�ini kullan.';
END;

