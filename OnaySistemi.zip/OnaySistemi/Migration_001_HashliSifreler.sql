USE OnaySystem;
GO

PRINT '===================================================================';
PRINT 'MIGRATION BA�LANIYOR: �ifreleri Hash''li Hale �evir';
PRINT '===================================================================';
GO

PRINT '';
PRINT 'Ad�m 1: Mevcut �ifreler Temizleniyor...';
UPDATE Kullanicilar SET Sifre = NULL;

PRINT '? T�m �ifreler bo�alt�ld�.';

GO

PRINT '';
PRINT 'Ad�m 2: Hash''li �ifreler Ekleniyor...';
PRINT '? �ifreler haz�rland� (NULL).';

PRINT '';
PRINT '===================================================================';
PRINT 'MIGRATION TAMAMLANDI!';
PRINT '===================================================================';
PRINT '';
PRINT 'SONRAKI ADIM:';
PRINT '1. Visual Studio''da a�a��daki kodu �al��t�r:';
PRINT '   string hash = SifreServisi.SifreHashle("1234");';
PRINT '   MessageBox.Show(hash);';
PRINT '';
PRINT '2. Hash de�erini kopyala';
PRINT '';
PRINT '3. SSMS''de �al��t�r:';
PRINT '   UPDATE Kullanicilar SET Sifre = ''BURAYA_YAPISTIR'' WHERE Sifre IS NULL;';
PRINT '';
PRINT '===================================================================';

GO

SELECT 
    KullaniciAdi,
    AdSoyad,
    CASE 
        WHEN Sifre IS NULL THEN 'NULL (Hash bekliyor)'
        ELSE 'Hash kaydedildi'
    END as SifreStatus,
    Rol
FROM Kullanicilar
ORDER BY KullaniciAdi;

GO
