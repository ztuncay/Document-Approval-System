PRINT 'BelgeGonderim tablosuna GonderenId alani ekleniyor...';
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'BelgeGonderim' AND COLUMN_NAME = 'GonderenId')
BEGIN
    ALTER TABLE BelgeGonderim
    ADD GonderenId INT NULL;
    
    PRINT 'GonderenId alani eklendi.';
END
ELSE
BEGIN
    PRINT 'GonderenId alani zaten mevcut.';
END;
GO

UPDATE bg
SET bg.GonderenId = k.Id
FROM BelgeGonderim bg
INNER JOIN Kullanicilar k ON k.KullaniciAdi = bg.GonderenKullaniciAdi
WHERE bg.GonderenId IS NULL;

PRINT 'Mevcut kayitlardaki GonderenId degerleri guncellendi.';
GO

IF NOT EXISTS (SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS 
               WHERE TABLE_NAME = 'Kullanicilar' AND COLUMN_NAME = 'Direktorluk')
BEGIN
    ALTER TABLE Kullanicilar
    ADD Direktorluk NVARCHAR(200) NULL;
    
    PRINT 'Kullanicilar tablosuna Direktorluk alani eklendi.';
END
ELSE
BEGIN
    PRINT 'Direktorluk alani zaten mevcut.';
END;
GO

PRINT 'Islem tamamlandi!';
GO
