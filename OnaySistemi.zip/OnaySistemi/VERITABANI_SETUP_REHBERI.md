# Veritaban� Setup Rehberi

## ?? Mevcut Durum

**Connection String:** 
```
Server=(localdb)\MSSQLLocalDB;Database=OnaySystem;Trusted_Connection=True;
```

Bu demek ki:
- ? **LocalDB** kullan�l�yor (SQL Server Express'in lightweight versiyonu)
- ? **Windows Authentication** (Trusted Connection)
- ? **Database ad�:** OnaySystem

---

## ?? Setup Y�ntemleri (Hepsini S�rada Yap�n)

### **Y�NTEM� 1: SQL Server Management Studio (SSMS) - �NER�LEN**

#### Ad�m 1: SSMS'i A��n
```
Windows Ba�lat ? "SQL Server Management Studio" yaz�p �al��t�r�n
```

#### Ad�m 2: LocalDB'ye Ba�lan
1. **Connect to Server** penceresinde:
   - **Server name:** `(localdb)\MSSQLLocalDB` yaz�n
   - **Authentication:** Windows Authentication se�in
   - **Connect** butonuna t�klay�n

#### Ad�m 3: Veritaban� Var m� Kontrol Edin
1. Sol taraftaki **Databases** klas�r�ne �ift t�klay�n
2. **OnaySystem** var m� bak:
   - ? **Yoksa:** Ad�m 4'� yap�n
   - ? **Varsa:** Ad�m 5'e ge�

#### Ad�m 4: Veritaban�n� Olu�tur (Sadece yoksa)
```sql
CREATE DATABASE OnaySystem
COLLATE Turkish_CI_AS;
```

**Bu kodu SSMS'de:**
1. **New Query** butonuna t�klay�n
2. Yukar�daki kodu yap��t�r�n
3. **Execute** (F5) tu�una bas�n

#### Ad�m 5: Temel Tablolar Var m� Kontrol Edin
```sql
USE OnaySystem;

-- A�a��daki tablolar� kontrol et
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES;
```

**Bu kodla a�a��daki tablolar� g�rebilmen gerekir:**
- ? `Kullanicilar`
- ? `BelgeGonderim`
- ?? `BelgeLog` (yoksa eklenecek)

#### Ad�m 6: SQL_SCRIPT_SETUP.sql'i �al��t�r
1. SSMS'de **File** ? **Open** ? **File...**
2. `SQL_SCRIPT_SETUP.sql` dosyas�n� se�
3. **Execute** (F5) tu�una bas
4. **Output** penceresinde mesajlar� oku:
   ```
   BelgeLog tablosu ba�ar�yla olu�turuldu.
   VersiyonNo kolonu eklendi.
   KayitTarihi kolonu eklendi.
   ...
   ```

---

### **Y�NTEM� 2: Visual Studio'dan (H�zl�)**

#### Ad�m 1: Visual Studio'da SQL Script Dosyas�n� A�
1. Solution Explorer'da **SQL_SCRIPT_SETUP.sql**'e sa� t�kla
2. **Execute** se�ene�ine t�kla (veya **Ctrl+Shift+E**)

#### Ad�m 2: Ba�lant� Se�
1. **Connect to Database Engine** penceresinde:
   - **Server name:** `(localdb)\MSSQLLocalDB`
   - **Database:** `OnaySystem`
   - **Connect** t�kla

#### Ad�m 3: Script �al��s�n
- Script otomatik olarak �al��acak
- ��k��� g�rmek i�in **View** ? **Output**

---

### **Y�NTEM� 3: Uygulamadan (C# Kodu ile)**

E�er SSMS yoksa, a�a��daki C# program� �al��t�rabilirsin:

```csharp
using System;
using System.Data.SqlClient;
using System.IO;

class DatabaseSetup
{
    static void Main()
    {
        string masterConnection = "Server=(localdb)\\MSSQLLocalDB;Database=master;Trusted_Connection=True;";
        string scriptPath = @"C:\YourPath\SQL_SCRIPT_SETUP.sql"; // D�zelt
        
        try
        {
            // 1. Veritaban� olu�tur
            using (SqlConnection conn = new SqlConnection(masterConnection))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(
                    "IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = 'OnaySystem') " +
                    "CREATE DATABASE OnaySystem COLLATE Turkish_CI_AS;", conn))
                {
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("? Veritaban� haz�r");
                }
            }

            // 2. SQL script'i �al��t�r
            string script = File.ReadAllText(scriptPath);
            string dbConnection = "Server=(localdb)\\MSSQLLocalDB;Database=OnaySystem;Trusted_Connection=True;";
            
            using (SqlConnection conn = new SqlConnection(dbConnection))
            {
                conn.Open();
                string[] commands = script.Split(new[] { "GO" }, StringSplitOptions.RemoveEmptyEntries);
                
                foreach (string cmd in commands)
                {
                    if (string.IsNullOrWhiteSpace(cmd)) continue;
                    
                    using (SqlCommand sqlCmd = new SqlCommand(cmd, conn))
                    {
                        sqlCmd.CommandTimeout = 300;
                        sqlCmd.ExecuteNonQuery();
                    }
                }
                
                Console.WriteLine("? T�m tablolar olu�turuldu");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("? Hata: " + ex.Message);
        }
    }
}
```

---

## ? Do�rulama (Setup Ba�ar�l� m�?)

### Test 1: Tablolar� Kontrol Et
```sql
USE OnaySystem;
GO

-- Tablolar� listele
SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES;

-- Beklenen ��k��:
-- Kullanicilar
-- BelgeGonderim
-- BelgeLog
```

### Test 2: Kolonlar� Kontrol Et
```sql
USE OnaySystem;
GO

-- BelgeGonderim kolonlar�n� kontrol et
SELECT COLUMN_NAME 
FROM INFORMATION_SCHEMA.COLUMNS 
WHERE TABLE_NAME = 'BelgeGonderim'
ORDER BY ORDINAL_POSITION;

-- A�a��daki kolonlar olmal�:
-- Id, DokumanTuru, Direktorluk, Konu, Aciklama, DosyaYolu,
-- OnayDurumu, Onayci1Id, Onayci2Id, VersiyonNo, KayitTarihi,
-- OncekiId, ImzaliDosya1Yolu, ImzaliDosya2Yolu, GonderenKullaniciAdi,
-- Onaylayan, OnayTarihi
```

### Test 3: �rnek Kullan�c� Ekle
```sql
USE OnaySystem;
GO

-- Kullan�c� ekle
INSERT INTO Kullanicilar (KullaniciAdi, AdSoyad, Rol)
VALUES ('ztuncay', 'Zeynep Tuncay', 'Kalite');

-- Kontrol et
SELECT * FROM Kullanicilar;
```

### Test 4: Uygulamay� �al��t�r
1. Visual Studio'da **Debug** ? **Start Debugging** (F5)
2. Giri� ekran�nda:
   - **Kullan�c� ad�:** `ztuncay`
   - **�ifre:** Bo� b�rak
   - **Giri�** t�kla

---

## ?? Yayg�n Hatalar ve ��z�mleri

### Hata 1: "Cannot open database 'OnaySystem'"
**Sebep:** Veritaban� olu�turulmam��

**��z�m:**
```sql
-- Master veritaban�nda �al��t�r
CREATE DATABASE OnaySystem
COLLATE Turkish_CI_AS;
GO
```

---

### Hata 2: "Cannot find column 'VersiyonNo'"
**Sebep:** SQL_SCRIPT_SETUP.sql �al��t�r�lmam��

**��z�m:**
```sql
USE OnaySystem;
GO

-- SQL_SCRIPT_SETUP.sql'in t�m kodunu �al��t�r
-- (Yukar�daki Y�NTEM� 1 - Ad�m 6'y� tekrarla)
```

---

### Hata 3: "Login failed for user 'NT AUTHORITY\SYSTEM'"
**Sebep:** Windows Authentication problemi

**��z�m:** App.config'i kontrol et:
```xml
<add name="OnaySystem"
     connectionString="Server=(localdb)\MSSQLLocalDB;Database=OnaySystem;Trusted_Connection=True;TrustServerCertificate=True;"
     providerName="System.Data.SqlClient" />
```

---

### Hata 4: "LocalDB instance does not exist"
**Sebep:** LocalDB kurulu de�il

**��z�m:** 
Visual Studio'nun SQL Server Object Explorer arac�l���yla kurulum yapabilirsin:
1. **View** ? **SQL Server Object Explorer**
2. **(localdb)\MSSQLLocalDB**'ye sa� t�kla
3. **Create New Database** ? `OnaySystem` yaz

---

## ?? Kurulum Checklist

- [ ] **Ad�m 1:** SSMS a� veya VS'de SQL taray�c�s�n� a�
- [ ] **Ad�m 2:** `(localdb)\MSSQLLocalDB`'ye ba�lan
- [ ] **Ad�m 3:** OnaySystem veritaban�n� kontrol et (yoksa olu�tur)
- [ ] **Ad�m 4:** SQL_SCRIPT_SETUP.sql'i �al��t�r
- [ ] **Ad�m 5:** Tablolar� Test 1 ile kontrol et
- [ ] **Ad�m 6:** Kolonlar� Test 2 ile kontrol et
- [ ] **Ad�m 7:** Test 3 ile kullan�c� ekle
- [ ] **Ad�m 8:** Uygulamay� Test 4 ile �al��t�r

---

## ?? �pu�lar�

1. **LocalDB verilerinin yeri:**
   ```
   C:\Users\<UserName>\AppData\Local\Microsoft\Microsoft SQL Server Local DB
   ```

2. **Script hatas� al�rsan:**
   - Script'i sat�rlar aras�nda b�l
   - Kopyala ? SSMS'de yap��t�r ? F5 bas

3. **Yinelenen hata al�rsan:**
   ```sql
   -- Veritaban�n� sil ve yeniden olu�tur
   DROP DATABASE OnaySystem;
   GO
   CREATE DATABASE OnaySystem COLLATE Turkish_CI_AS;
   GO
   ```

4. **Destek:**
   - SSMS'de `?` tu�una basarak help al
   - SQL Intellisense (Ctrl+Space) kullan

---

## ?? Tamamland� m�?

E�er t�m testleri ba�ar�yla ge�tiysen:
? **Veritaban� haz�r**
? **T�m tablolar var**
? **Kolonlar eklenmi�**
? **Uygulamay� �al��t�rabilirsin**

Sorunda kal�rsan, error mesaj�n� payla�! ??
