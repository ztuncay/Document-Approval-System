#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
�ifre Hash Olu�turucu ve Database G�ncelleyici
T�m kullan�c�lara otomatik hash'li �ifre atar.
"""

import hashlib
import base64
import secrets
import sqlite3
import pyodbc

# ===================================================================
# KONF�G�RASYON
# ===================================================================

# Test �ifresi
TEST_SIFRE = "1234"

# SQL Server Ba�lant�
SERVER = "(localdb)\\MSSQLLocalDB"
DATABASE = "OnaySystem"
DRIVER = "ODBC Driver 17 for SQL Server"

# ===================================================================
# SHA256 + SALT HASH OLU�TURUCU
# ===================================================================

def sifre_hashle(sifre):
    """�ifreyi SHA256+Salt ile hash'le ve Base64'e �evir."""
    # 1. Random salt �ret (16 byte)
    salt = secrets.token_bytes(16)
    
    # 2. �ifre + salt'� SHA256'ya g�nder
    sifre_bytes = sifre.encode('utf-8')
    sifre_saltli = salt + sifre_bytes
    
    hash_obj = hashlib.sha256(sifre_saltli)
    hash_bytes = hash_obj.digest()
    
    # 3. Salt + Hash'i Base64'e �evir
    salt_ve_hash = salt + hash_bytes
    hash_base64 = base64.b64encode(salt_ve_hash).decode('utf-8')
    
    return hash_base64

def database_guncelle(hash_degeri):
    """Veritaban�n� hash'li �ifrelerle g�ncelle."""
    try:
        # SQL Server'a ba�lan
        baglanti_str = f"Driver={{{DRIVER}}};Server={SERVER};Database={DATABASE};Trusted_Connection=yes;"
        baglanti = pyodbc.connect(baglanti_str)
        cursor = baglanti.cursor()
        
        print("? Veritaban�na ba�land�.")
        
        # T�m NULL �ifreleri g�ncelle
        sql = f"""
        UPDATE Kullanicilar 
        SET Sifre = ?
        WHERE Sifre IS NULL;
        """
        
        cursor.execute(sql, hash_degeri)
        baglanti.commit()
        
        # Ka� sat�r g�ncellendi?
        satir_sayisi = cursor.rowcount
        print(f"? {satir_sayisi} kullan�c�ya �ifre atand�.")
        
        # Kontrol
        cursor.execute("SELECT KullaniciAdi, Sifre FROM Kullanicilar;")
        print("\n?? Veritaban�nda Kay�tl� Kullan�c�lar:")
        for row in cursor.fetchall():
            kullanici_adi = row[0]
            sifre = row[1]
            sifre_durum = "? Hash kaydedildi" if sifre else "? NULL"
            print(f"  {kullanici_adi}: {sifre_durum}")
        
        cursor.close()
        baglanti.close()
        
        return True
    
    except Exception as e:
        print(f"? Hata: {e}")
        return False

# ===================================================================
# ANA PROGRAM
# ===================================================================

def main():
    print("=" * 70)
    print("��FRE HASH OLU�TURUCU VE DATABASE G�NCELLEYICI")
    print("=" * 70)
    print()
    
    # 1. Hash olu�tur
    print(f"�ifre: '{TEST_SIFRE}'")
    print("Hash olu�turuluyor...")
    
    hash_degeri = sifre_hashle(TEST_SIFRE)
    
    print()
    print("? Hash Olu�turuldu:")
    print(f"  {hash_degeri}")
    print()
    
    # 2. Veritaban�n� g�ncelle
    print("Veritaban� G�ncelleniyor...")
    basarili = database_guncelle(hash_degeri)
    
    print()
    if basarili:
        print("=" * 70)
        print("? BA�ARILI!")
        print("=" * 70)
        print()
        print(f"Art�k giri� yapabilirsin:")
        print(f"  Kullan�c�: ztuncay")
        print(f"  �ifre: {TEST_SIFRE}")
        print()
    else:
        print("? HATA!")
        print("Python'da SQL Server ODBC driver kurulu mu kontrol et.")
        print()
        print("Kurma (Command Prompt'ta):")
        print("  pip install pyodbc")
        print()
        print("ODBC Driver:")
        print("  https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server")

if __name__ == "__main__":
    main()
