using System;
using System.Configuration;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace OnaySistemi
{
    public partial class FrmAdminPanel : Form
    {
        private readonly string _baglantiMetni;

        public FrmAdminPanel()
        {
            InitializeComponent();
            _baglantiMetni = ConfigurationManager.ConnectionStrings["OnaySystem"].ConnectionString;
        }

        private void FrmAdminPanel_Load(object sender, EventArgs e)
        {
            lblAdminBaslik.Text = $"Admin Paneli - Ho�geldiniz {OturumBilgisi.AdSoyad}";
            
            tabControl.SelectedIndex = 0;
            KullaniciListesiYukle();
        }

        private void KullaniciListesiYukle()
        {
            try
            {
                using (SqlConnection baglanti = new SqlConnection(_baglantiMetni))
                using (SqlCommand komut = new SqlCommand(@"
                    SELECT Id, KullaniciAdi, AdSoyad, Rol, AktifMi, OlusturulmaTarihi
                    FROM Kullanicilar
                    ORDER BY OlusturulmaTarihi DESC", baglanti))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(komut);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvKullanicilar.DataSource = dt;
                    
                    dgvKullanicilar.Columns["Id"].HeaderText = "ID";
                    dgvKullanicilar.Columns["KullaniciAdi"].HeaderText = "Kullan�c� Ad�";
                    dgvKullanicilar.Columns["AdSoyad"].HeaderText = "Ad Soyad";
                    dgvKullanicilar.Columns["Rol"].HeaderText = "Rol";
                    dgvKullanicilar.Columns["AktifMi"].HeaderText = "Aktif";
                    dgvKullanicilar.Columns["OlusturulmaTarihi"].HeaderText = "Olu�turulma Tarihi";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kullan�c� listesi y�klenirken hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnKullaniciEkle_Click(object sender, EventArgs e)
        {
            using (var frm = new FrmKullaniciDuzenle())
            {
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    KullaniciListesiYukle();
                }
            }
        }

        private void btnKullaniciDuzenle_Click(object sender, EventArgs e)
        {
            if (dgvKullanicilar.SelectedRows.Count == 0)
            {
                MessageBox.Show("L�tfen d�zenlemek istedi�iniz kullan�c�y� se�in.", "Uyar�");
                return;
            }

            int kullaniciId = (int)dgvKullanicilar.SelectedRows[0].Cells["Id"].Value;
            
            using (var frm = new FrmKullaniciDuzenle(kullaniciId))
            {
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    KullaniciListesiYukle();
                }
            }
        }

        private void btnKullaniciSil_Click(object sender, EventArgs e)
        {
            if (dgvKullanicilar.SelectedRows.Count == 0)
            {
                MessageBox.Show("L�tfen silmek istedi�iniz kullan�c�y� se�in.", "Uyar�");
                return;
            }

            int kullaniciId = (int)dgvKullanicilar.SelectedRows[0].Cells["Id"].Value;
            string kullaniciAdi = dgvKullanicilar.SelectedRows[0].Cells["KullaniciAdi"].Value.ToString();
            string adSoyad = dgvKullanicilar.SelectedRows[0].Cells["AdSoyad"].Value.ToString();

            if (MessageBox.Show($"{adSoyad} adl� kullan�c�y� silmek istedi�inize emin misiniz?", 
                "Silme Onay�", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                using (SqlConnection baglanti = new SqlConnection(_baglantiMetni))
                using (SqlCommand komut = new SqlCommand("DELETE FROM Kullanicilar WHERE Id = @Id", baglanti))
                {
                    komut.Parameters.AddWithValue("@Id", kullaniciId);
                    baglanti.Open();
                    komut.ExecuteNonQuery();
                }

                AuditLogHelper.KullaniciSilindi(kullaniciId, adSoyad);

                MessageBox.Show("Kullan�c� ba�ar�yla silindi.", "Ba�ar�l�", MessageBoxButtons.OK, MessageBoxIcon.Information);
                KullaniciListesiYukle();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kullan�c� silinirken hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl.SelectedIndex == 1)
            {
                BelgeListesiYukle();
            }
        }

        private void BelgeListesiYukle()
        {
            try
            {
                using (SqlConnection baglanti = new SqlConnection(_baglantiMetni))
                using (SqlCommand komut = new SqlCommand(@"
                    SELECT 
                        Id, DokumanTuru, Konu, OnayDurumu, GonderenAdSoyad, 
                        Onaylayan, KayitTarihi, VersiyonNo
                    FROM BelgeGonderim
                    ORDER BY KayitTarihi DESC", baglanti))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(komut);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dgvBelgeler.DataSource = dt;

                    dgvBelgeler.Columns["Id"].HeaderText = "ID";
                    dgvBelgeler.Columns["DokumanTuru"].HeaderText = "D�k�man T�r�";
                    dgvBelgeler.Columns["Konu"].HeaderText = "Konu";
                    dgvBelgeler.Columns["OnayDurumu"].HeaderText = "Onay Durumu";
                    dgvBelgeler.Columns["GonderenAdSoyad"].HeaderText = "G�nderen";
                    dgvBelgeler.Columns["Onaylayan"].HeaderText = "Onaylayan";
                    dgvBelgeler.Columns["KayitTarihi"].HeaderText = "Kay�t Tarihi";
                    dgvBelgeler.Columns["VersiyonNo"].HeaderText = "Versiyon";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Belge listesi y�klenirken hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBelgeDurumuDegistir_Click(object sender, EventArgs e)
        {
            if (dgvBelgeler.SelectedRows.Count == 0)
            {
                MessageBox.Show("L�tfen durumunu de�i�tirmek istedi�iniz belgeyi se�in.", "Uyar�");
                return;
            }

            int belgeId = (int)dgvBelgeler.SelectedRows[0].Cells["Id"].Value;
            string suankiDurum = dgvBelgeler.SelectedRows[0].Cells["OnayDurumu"].Value?.ToString() ?? "";

            using (var frm = new FrmBelgeDurumuDegistir(belgeId, suankiDurum))
            {
                if (frm.ShowDialog() == DialogResult.OK)
                {
                    BelgeListesiYukle();
                }
            }
        }

        private void btnBelgeSil_Click(object sender, EventArgs e)
        {
            if (dgvBelgeler.SelectedRows.Count == 0)
            {
                MessageBox.Show("L�tfen silmek istedi�iniz belgeyi se�in.", "Uyar�");
                return;
            }

            int belgeId = (int)dgvBelgeler.SelectedRows[0].Cells["Id"].Value;
            string konu = dgvBelgeler.SelectedRows[0].Cells["Konu"].Value?.ToString() ?? "Belirtilmemi�";

            if (MessageBox.Show($"'{konu}' ba�l�kl� belgeyi silmek istedi�inize emin misiniz?\n\nBu i�lem geri al�namaz!", 
                "Silme Onay�", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                using (SqlConnection baglanti = new SqlConnection(_baglantiMetni))
                using (SqlCommand komut = new SqlCommand("DELETE FROM BelgeGonderim WHERE Id = @Id", baglanti))
                {
                    komut.Parameters.AddWithValue("@Id", belgeId);
                    baglanti.Open();
                    komut.ExecuteNonQuery();
                }

                AuditLogHelper.BelgeSilindi(belgeId, konu);

                MessageBox.Show("Belge ba�ar�yla silindi.", "Ba�ar�l�", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BelgeListesiYukle();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Belge silinirken hata: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnKapat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnIslemGecmisi_Click(object sender, EventArgs e)
        {
            using (var frm = new FrmAuditLog())
            {
                frm.ShowDialog(this);
            }
        }
    }
}
