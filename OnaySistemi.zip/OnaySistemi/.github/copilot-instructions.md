# Copilot Instructions

## General Guidelines
- Write documentation in a very detailed, step-by-step manner.
- Maintain a simple-to-understand approach while keeping a formal corporate tone.

## Code Style
- Use specific formatting rules.
- Follow naming conventions.

## Project-Specific Rules
- Custom requirement A.
- Custom requirement B.