using System;
using System.Configuration;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace OnaySistemi
{
    public partial class FrmAuditLog : Form
    {
        private readonly string _baglantiMetni;

        public FrmAuditLog()
        {
            InitializeComponent();
            _baglantiMetni = ConfigurationManager.ConnectionStrings["OnaySystem"].ConnectionString;
        }

        private void FrmAuditLog_Load(object sender, EventArgs e)
        {
            lblBaslik.Text = $"��lem Ge�mi�i - Yap�lan T�m De�i�iklikler";
            
            cmbIslemTipi.Items.Clear();
            cmbIslemTipi.Items.Add("-- T�m� --");
            cmbIslemTipi.Items.Add("Kullanici_Ekle");
            cmbIslemTipi.Items.Add("Kullanici_Duzenle");
            cmbIslemTipi.Items.Add("Kullanici_Sil");
            cmbIslemTipi.Items.Add("Belge_Durum_Degistir");
            cmbIslemTipi.Items.Add("Belge_Sil");
            cmbIslemTipi.SelectedIndex = 0;

            cmbTablo.Items.Clear();
            cmbTablo.Items.Add("-- T�m� --");
            cmbTablo.Items.Add("Kullanicilar");
            cmbTablo.Items.Add("BelgeGonderim");
            cmbTablo.SelectedIndex = 0;

            dtpBaslangic.Value = DateTime.Today.AddDays(-30);
            dtpBitis.Value = DateTime.Today.AddDays(1);

            LoglariYukle();
        }

        private void LoglariYukle()
        {
            try
            {
                string islemTipi = cmbIslemTipi.SelectedItem?.ToString() ?? "-- T�m� --";
                string tablo = cmbTablo.SelectedItem?.ToString() ?? "-- T�m� --";
                DateTime baslangic = dtpBaslangic.Value;
                DateTime bitis = dtpBitis.Value;

                string sorgu = @"
                    SELECT 
                        Id,
                        IslemTarihi,
                        KullaniciAdi,
                        IslemTipi,
                        Tablo,
                        KaydId,
                        Aciklama
                    FROM AuditLog
                    WHERE IslemTarihi >= @Baslangic AND IslemTarihi <= @Bitis";

                if (islemTipi != "-- T�m� --")
                    sorgu += " AND IslemTipi = @IslemTipi";

                if (tablo != "-- T�m� --")
                    sorgu += " AND Tablo = @Tablo";

                if (!string.IsNullOrWhiteSpace(txtAra.Text))
                    sorgu += " AND (KullaniciAdi LIKE @Ara OR Aciklama LIKE @Ara)";

                sorgu += " ORDER BY IslemTarihi DESC";

                using (SqlConnection baglanti = new SqlConnection(_baglantiMetni))
                using (SqlCommand komut = new SqlCommand(sorgu, baglanti))
                {
                    komut.Parameters.AddWithValue("@Baslangic", baslangic);
                    komut.Parameters.AddWithValue("@Bitis", bitis);

                    if (islemTipi != "-- T�m� --")
                        komut.Parameters.AddWithValue("@IslemTipi", islemTipi);

                    if (tablo != "-- T�m� --")
                        komut.Parameters.AddWithValue("@Tablo", tablo);

                    if (!string.IsNullOrWhiteSpace(txtAra.Text))
                        komut.Parameters.AddWithValue("@Ara", "%" + txtAra.Text + "%");

                    SqlDataAdapter adapter = new SqlDataAdapter(komut);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgvLoglar.DataSource = dt;

                    dgvLoglar.Columns["Id"].HeaderText = "ID";
                    dgvLoglar.Columns["IslemTarihi"].HeaderText = "��lem Tarihi";
                    dgvLoglar.Columns["KullaniciAdi"].HeaderText = "Kullan�c�";
                    dgvLoglar.Columns["IslemTipi"].HeaderText = "��lem Tipi";
                    dgvLoglar.Columns["Tablo"].HeaderText = "Tablo";
                    dgvLoglar.Columns["KaydId"].HeaderText = "Kay�t ID";
                    dgvLoglar.Columns["Aciklama"].HeaderText = "A��klama";

                    lblToplamIslem.Text = $"Toplam ��lem: {dt.Rows.Count}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Loglar y�klenirken hata: " + ex.Message, "Hata");
            }
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            LoglariYukle();
        }

        private void cmbIslemTipi_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoglariYukle();
        }

        private void cmbTablo_SelectedIndexChanged(object sender, EventArgs e)
        {
            LoglariYukle();
        }

        private void txtAra_TextChanged(object sender, EventArgs e)
        {
            LoglariYukle();
        }

        private void dtpBaslangic_ValueChanged(object sender, EventArgs e)
        {
            LoglariYukle();
        }

        private void dtpBitis_ValueChanged(object sender, EventArgs e)
        {
            LoglariYukle();
        }

        private void btnDetay_Click(object sender, EventArgs e)
        {
            if (dgvLoglar.SelectedRows.Count == 0)
            {
                MessageBox.Show("L�tfen bir i�lem se�in.");
                return;
            }

            DataGridViewRow seciliSatir = dgvLoglar.SelectedRows[0];
            int logId = (int)seciliSatir.Cells["Id"].Value;

            try
            {
                using (SqlConnection baglanti = new SqlConnection(_baglantiMetni))
                using (SqlCommand komut = new SqlCommand(
                    "SELECT * FROM AuditLog WHERE Id = @Id", baglanti))
                {
                    komut.Parameters.AddWithValue("@Id", logId);
                    baglanti.Open();

                    using (SqlDataReader dr = komut.ExecuteReader())
                    {
                        if (dr.Read())
                        {
                            string detay = $@"
��LEM GE�M��� DETAYI
{'='*50}

��lem ID: {dr["Id"]}
��lem Tarihi: {dr["IslemTarihi"]}
Kullan�c�: {dr["KullaniciAdi"]}
��lem Tipi: {dr["IslemTipi"]}
Tablo: {dr["Tablo"]}
Kay�t ID: {dr["KaydId"]}
A��klama: {dr["Aciklama"]}

{'='*50}";

                            MessageBox.Show(detay, "��lem Detay�", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Detay y�klenirken hata: " + ex.Message);
            }
        }

        private void btnKapat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
