# ? SISTEM KONTROL CHECK-L�ST

## ?? PRE-TEST (Veritaban� Haz�rl���)

- [ ] Sifre kolonu NULL kabul ediyor mu?
  ```sql
  ALTER TABLE Kullanicilar ALTER COLUMN Sifre NVARCHAR(255) NULL;
  ```

- [ ] �mza klas�r� olu�turuldu mu?
  ```
  C:\...\Imzalar\
  ```

- [ ] �mza dosyalar� var m�?
  ```
  ztuncay.png
  ahmet_director.png
  fatih_director.png
  view_only.png
  ```

---

## ?? TEST 1: G�R�� AKI�I

- [ ] F5 (Debug) ? Uygulama �al���yor
- [ ] Giri� Ekran� a��l�yor
- [ ] Kullan�c� Ad�: `ztuncay`
- [ ] �ifre: (bo� b�rak)
- [ ] Giri� Butonuna Bas
- [ ] ? Ana Men�ye Gidiyor
- [ ] �st k�rm�z� �erit: "Kullan�c�: Zeynep Tuncay"

---

## ?? TEST 2: ROL Y�NET�M� (Kalite Rol�)

**Beklenen:** 3 buton aktif
- [ ] **Belge G�nderimi** - Mavi
- [ ] **Revize Tamamlama** - Mavi  
- [ ] **Belge Listesi** - Mavi
- [ ] **Onay Ekran�** - KIRMIZI (deaktif)

**�zet Panel Kontrol�:**
- [ ] "Genel �zet (Kalite)" ba�l��� g�r�l�yor
- [ ] "Beklemede belge say�s�" numaras� g�r�l�yor
- [ ] "Bug�n g�nderilen belge" numaras� g�r�l�yor

---

## ?? TEST 3: BELGE G�NDER�M�

**Ad�mlar:**
1. [ ] "Belge G�nderimi" Butonuna T�kla
2. [ ] **Dok�man T�r� Se�** (Kalite El Kitab�)
3. [ ] **Direkt�rl�k Se�** (Direkt 1)
4. [ ] **Konu Yaz** ("Test Belgesi")
5. [ ] **A��klama Yaz** (Opsiyonel)
6. [ ] **Dosya Se�** (Herhangi bir PDF)
7. [ ] **1. Onayc� Se�** (Ahmet Y�netici)
8. [ ] **2. Onayc� Se�** (Fatih Direkt�r) - Opsiyonel
9. [ ] **G�nder** Butonuna Bas

**Beklenen Sonu�lar:**
- [ ] Mesaj: "Dosya kopyaland� ve kay�t veritaban�na eklendi."
- [ ] Dosya klas�rde var: `C:\...\Orijinal Dok�manlar\20240206_120000_dosyaAdi.pdf`
- [ ] BelgeGonderim tablosunda yeni kay�t:
  ```sql
  SELECT * FROM BelgeGonderim WHERE DokumanTuru = 'Kalite El Kitab�' ORDER BY Id DESC;
  ```
- [ ] BelgeLog tablosunda "G�nderildi" kayd�:
  ```sql
  SELECT * FROM BelgeLog WHERE BelgeId = (son id) ORDER BY IslemTarihi DESC;
  ```

---

## ?? TEST 4: BELGE L�STES�

**Ad�mlar:**
1. [ ] Ana Men�ye Geri D�n
2. [ ] "Belge Listesi" Butonuna T�kla

**Beklenen Sonu�lar:**
- [ ] Grid'de en son g�nderdi�in belge en �stte
- [ ] Kolon ba�l�klar� g�r�l�yor:
  - Dok�man T�r�
  - Direkt�rl�k
  - Konu
  - G�nderen
  - Durum (Beklemede)
  - Kay�t Tarihi
- [ ] Durum: "Beklemede"
- [ ] Sat�ra �ift T�kla ? PDF a��l�yor (orijinal)

---

## ?? TEST 5: 1. ONAY

**Ad�mlar:**
1. [ ] Uygulamay� Kapat (File ? Exit)
2. [ ] F5 (Debug) ? Yeniden Ba�lat
3. [ ] Kullan�c� Ad�: `ahmet_director`
4. [ ] �ifre: (bo�)
5. [ ] Giri�
6. [ ] "Onay Ekran�" Butonuna T�kla

**Beklenen Sonu�lar:**
- [ ] Bilgeyi g�nderdi�in belge **listede g�r�l�yor**
- [ ] Durum: "Beklemede"
- [ ] **Belgeyi Se�** ? Sa�da Detaylar g�steriliyor
- [ ] **Onayla** Butonuna T�kla

**Beklenen Sonu�lar (Onay Sonras�):**
- [ ] Mesaj: "�mzal� belge olu�turuldu: ...1_imzali.pdf"
- [ ] Dosya klas�rde var: `...1_imzali.pdf`
- [ ] **Listeyi Yenile** (F5)
- [ ] Belge durumu de�i�ti:
  - 2. Onayc� varsa: "1. Onayland�, 2. Beklemede"
  - 2. Onayc� yoksa: "Onayland�"
- [ ] BelgeLog'da "1. Onay" kayd�:
  ```sql
  SELECT * FROM BelgeLog WHERE BelgeId = (belgeId) ORDER BY IslemTarihi DESC;
  ```

---

## ?? TEST 6: 2. ONAY (E�er 2. Onayc� Varsa)

**Ad�mlar:**
1. [ ] Uygulamay� Kapat
2. [ ] F5 (Debug) ? Yeniden Ba�lat
3. [ ] Kullan�c� Ad�: `fatih_director`
4. [ ] �ifre: (bo�)
5. [ ] Giri�
6. [ ] "Onay Ekran�" Butonuna T�kla

**Beklenen Sonu�lar:**
- [ ] Belge **listede g�r�l�yor** (durum: "1. Onayland�, 2. Beklemede")
- [ ] Belgeyi Se� ? Detaylar g�steriliyor
- [ ] **Onayla** Butonuna T�kla

**Beklenen Sonu�lar (2. Onay Sonras�):**
- [ ] Mesaj: "�mzal� belge olu�turuldu: ...2_imzali.pdf"
- [ ] Dosya klas�rde var: `...2_imzali.pdf`
- [ ] Belge durumu: "Tam Onayland�"
- [ ] BelgeLog'da "2. Onay" kayd�

---

## ?? TEST 7: VERS�YON GE�M���

**Ad�mlar:**
1. [ ] Ana Men�ye D�n
2. [ ] "Belge Listesi" T�kla
3. [ ] **Belgeyi Se�** (Onayland��� belge)
4. [ ] **Versiyon Ge�mi�i** Butonuna T�kla

**Beklenen Sonu�lar:**
- [ ] Yeni Form a��l�yor
- [ ] Grid'de kay�tlar:
  - VersiyonNo: 1
  - ��lem Tipi: "G�nderildi" ? "1. Onay" ? "2. Onay"
  - ��lem Tarihleri artan s�rada
  - ��lem Yapan: Ki�i isimleri
  - Dosya Yollar�

---

## ?? TEST 8: RED ��LEM�

**Ad�mlar:**
1. [ ] Yeni bir belge g�nder (TEST 3'� tekrarla)
2. [ ] ahmet_director ile giri� yap
3. [ ] "Onay Ekran�" ? Belgeyi Se�
4. [ ] **Reddet** Butonuna T�kla

**Beklenen Sonu�lar:**
- [ ] Onay �ste�i mesaj�: "Reddedilmi� olarak i�aretlemek istedi�inizden emin misiniz?"
- [ ] EVET se�ersen ? Durum: "Reddedildi"
- [ ] BelgeLog'da "Red" kayd�
- [ ] Belge art�k Onay Ekran�'nda g�r�lm�yor

---

## ?? TEST 9: REV�ZE TALEP

**Ad�mlar:**
1. [ ] Yeni bir belge g�nder (TEST 3'� tekrarla)
2. [ ] ahmet_director ile giri� yap
3. [ ] "Onay Ekran�" ? Belgeyi Se�
4. [ ] **Revize Talep Et** Butonuna T�kla

**Beklenen Sonu�lar:**
- [ ] InputBox: "Revize talebinizin gerek�esini yaz�n�z:"
- [ ] Yaz� yaz: "Sayfa numaralar� eklenmeli"
- [ ] OK tu�una bas
- [ ] Durum: "Revize Talep Edildi"
- [ ] BelgeLog'da "Revize Talep" kayd� (A��klama: yaz�lan metin)

---

## ?? TEST 10: REV�ZE TAMAMLAMA

**Ad�mlar:**
1. [ ] Ana Men�ye D�n (ztuncay ile)
2. [ ] "Revize Tamamlama" Butonuna T�kla
3. [ ] **Revize talebinin yap�ld��� belge** listede g�r�l�yor
4. [ ] Belgeyi Se�
5. [ ] **Revize Edilecek Belgeyi A�** ? Orijinal PDF a��l�yor
6. [ ] **Yeni Dosya Se�** ? Revize edilen PDF se�
7. [ ] **Revizeyi Tamamla** Butonuna T�kla

**Beklenen Sonu�lar:**
- [ ] Onay �ste�i: "Yeni versiyon (v2) olu�turulacak. Devam?"
- [ ] EVET se�ersen ? Mesaj: "Yeni versiyon olu�turuldu ve Beklemede durumuna al�nd�"
- [ ] Yeni dosya klas�rde: `...v2_dosyaAdi.pdf`
- [ ] BelgeGonderim'de yeni sat�r:
  - VersiyonNo: 2
  - OncekiId: (�nceki Id)
  - OnayDurumu: "Beklemede"
- [ ] BelgeLog'da "Revize Tamamlama" kayd�

---

## ?? SONU�

T�m testleri ba�ar�yla tamamlad�ysan:
? **Sistem %100 �al���yor!**

Hata ald�ysan:
? Hangi test ad�m�nda oldu�unu yaz
? Exact error mesaj�n� payla�
? Database log sorgular�n� �al��t�r

---

## ?? VERITABANI KOMUTLARI (Hata Durumunda)

```sql
-- T�m Belgeleri Kontrol Et
SELECT * FROM BelgeGonderim ORDER BY Id DESC;

-- T�m Loglar� Kontrol Et
SELECT * FROM BelgeLog ORDER BY IslemTarihi DESC;

-- Belgeye Ait Loglar� Kontrol Et
SELECT * FROM BelgeLog WHERE BelgeId = 1 ORDER BY IslemTarihi DESC;

-- Versiyon Zincirini Kontrol Et
SELECT Id, VersiyonNo, OncekiId, OnayDurumu FROM BelgeGonderim WHERE DokumanTuru LIKE '%El Kitab�%' ORDER BY Id;

-- Kullan�c�lar� Kontrol Et
SELECT * FROM Kullanicilar;

-- Sifre Hatas� Fix
UPDATE Kullanicilar SET Sifre = '' WHERE Sifre IS NULL;
```

---

**Ba�ar�lar!** ??
